
import importlib
import os
import sys
import traceback

class Controller:
    """
    Modular executive controller with unified working memory.
    Dynamically loads all modules from the core/ directory.
    Delegates arbitration and executive logic to ExecutiveFunctionModule.
    """

    def __init__(self, shared_context=None, working_memory=None, core_folder="core"):
        self.shared_context = shared_context if shared_context is not None else {}
        self.working_memory = working_memory
        self.modules = {}
        self._ensure_core_package(core_folder)
        self._load_core_modules(core_folder)
        # Always load ExecutiveFunctionModule as "executive_function"
        try:
            exec_mod = importlib.import_module("core.ExecutiveFunctionModule")
            self.executive = exec_mod.ExecutiveFunctionModule(shared_context=self.shared_context, working_memory=self.working_memory)
            self.modules["executive_function"] = self.executive
            print("Loaded module: executive_function")
        except Exception as e:
            print(f"Error loading executive_function: {e}")
            traceback.print_exc()

    def _ensure_core_package(self, core_folder):
        core_folder_abs = os.path.abspath(core_folder)
        parent_dir = os.path.dirname(core_folder_abs)
        if parent_dir not in sys.path:
            sys.path.insert(0, parent_dir)
        init_path = os.path.join(core_folder_abs, "__init__.py")
        if not os.path.exists(init_path):
            with open(init_path, "w") as f:
                f.write("# core package\n")

    def _load_core_modules(self, core_folder):
        for fname in os.listdir(core_folder):
            if (
                fname.endswith(".py")
                and not fname.startswith("__")
                and fname not in ("BaseModule.py", "ExecutiveFunctionModule.py", "WorkingMemoryManager.py")
            ):
                mod_name = fname[:-3]
                try:
                    module = importlib.import_module(f"core.{mod_name}")
                    class_name_variants = [
                        mod_name,
                        mod_name.lower(),
                        mod_name.capitalize(),
                        ''.join([part.capitalize() for part in mod_name.split('_')]),
                    ]
                    cls = None
                    for cname in class_name_variants:
                        cls = getattr(module, cname, None)
                        if cls:
                            break
                    if cls:
                        instance = cls(shared_context=self.shared_context, working_memory=self.working_memory)
                        if hasattr(instance, "initialize"):
                            instance.initialize()
                        self.modules[mod_name] = instance
                        print(f"Loaded module: {mod_name}")
                    else:
                        print(f"Class not found for {fname}. Tried: {class_name_variants}")
                except Exception as e:
                    print(f"Error loading {mod_name}: {e}")
                    traceback.print_exc()

    def route(self, module_name, user_input, **kwargs):
        key = module_name
        if key in self.modules:
            try:
                self.working_memory.add_input(user_input)
                result = self.modules[key].process(user_input, **kwargs)
                module_reports = {
                    mod: self.shared_context.get(f"{mod}_report", {})
                    for mod in self.modules
                }
                executive_result = self.executive.process(module_reports, context=self.shared_context)
                return {
                    "module_result": result,
                    "executive_decision": executive_result,
                    "shared_context": self.shared_context
                }
            except Exception as e:
                tb = traceback.format_exc()
                if hasattr(self.executive.routines, "error_handling"):
                    error_result = self.executive.routines["error_handling"].handle_module_error(key, e, self.shared_context)
                    return f"Error in module '{module_name}': {e}\n{tb}\nExecutive handled: {error_result}"
                else:
                    return f"Error in module '{module_name}': {e}\n{tb}"
        else:
            return f"Module '{module_name}' not found."

    def list_modules(self):
        return list(self.modules.keys())

    def reload_module(self, module_name, core_folder="core"):
        key = module_name
        fname = f"{module_name}.py"
        core_folder_abs = os.path.abspath(core_folder)
        if fname in os.listdir(core_folder):
            try:
                module = importlib.reload(importlib.import_module(f"core.{module_name}"))
                class_name_variants = [
                    module_name,
                    module_name.lower(),
                    module_name.capitalize(),
                    ''.join([part.capitalize() for part in module_name.split('_')]),
                ]
                cls = None
                for cname in class_name_variants:
                    cls = getattr(module, cname, None)
                    if cls:
                        break
                if cls:
                    instance = cls(shared_context=self.shared_context, working_memory=self.working_memory)
                    if hasattr(instance, "initialize"):
                        instance.initialize()
                    self.modules[key] = instance
                    print(f"Reloaded module: {module_name}")
                    return True
                else:
                    print(f"Class not found for {fname}. Tried: {class_name_variants}")
            except Exception as e:
                print(f"Error reloading {module_name}: {e}")
                traceback.print_exc()
        else:
            print(f"Module file '{fname}' not found in {core_folder}.")
        return False

    def module_info(self, module_name):
        key = module_name
        if key in self.modules:
            mod = self.modules[key]
            doc = getattr(mod, "__doc__", None)
            return doc or "No documentation available."
        else:
            return f"Module '{module_name}' not found."
