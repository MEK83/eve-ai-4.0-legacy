
from flask import Flask, request, jsonify
from flask_cors import CORS
import traceback

# Try to import Controller and handle errors gracefully
try:
    from Controller import Controller
except Exception as e:
    Controller = None
    print(f"[ERROR] Could not import Controller: {e}")
    traceback.print_exc()

app = Flask(__name__)
CORS(app)

# Attempt to instantiate the Controller and load all modules
controller = None
controller_error = None
if Controller:
    try:
        controller = Controller()
        print("[INFO] Controller initialized successfully.")
    except Exception as e:
        controller_error = str(e)
        print(f"[ERROR] Controller failed to initialize: {e}")
        traceback.print_exc()
else:
    controller_error = "Controller import failed."

@app.route('/modules', methods=['GET'])
def list_modules():
    if not controller:
        return jsonify({'error': f'Controller failed to initialize: {controller_error}'}), 500
    try:
        modules = controller.list_modules()
        # Defensive: ensure it's a list of strings
        if not isinstance(modules, list):
            modules = list(modules)
        modules = [str(m) for m in modules]
        print(f"[INFO] Modules available: {modules}")
        return jsonify({'modules': modules})
    except Exception as e:
        print(f"[ERROR] Failed to list modules: {e}")
        traceback.print_exc()
        return jsonify({'error': f'Failed to list modules: {str(e)}'}), 500

@app.route('/chat', methods=['POST'])
def chat():
    if not controller:
        return jsonify({'error': f'Controller failed to initialize: {controller_error}'}), 500
    try:
        data = request.get_json(force=True)
        module_name = data.get('module')
        message = data.get('message', '')
        context = data.get('context', None)
        action = data.get('action', 'generate_response')
        backend = data.get('backend', 'mistral')
        extra_kwargs = {k: v for k, v in data.items() if k not in ['module', 'message', 'context', 'action', 'backend']}
        if not module_name or not message:
            return jsonify({'error': "Both 'module' and 'message' are required."}), 400
        # Defensive: check if module exists
        available_modules = controller.list_modules()
        if module_name not in available_modules:
            return jsonify({'error': f"Module '{module_name}' not found. Available modules: {available_modules}"}), 400
        result = controller.route(
            module_name,
            message,
            context,
            action=action,
            backend=backend,
            **extra_kwargs
        )
        return jsonify({'response': result})
    except Exception as e:
        print(f"[ERROR] Internal server error: {e}")
        traceback.print_exc()
        return jsonify({'error': f'Internal server error: {str(e)}'}), 500

@app.route('/')
def index():
    return jsonify({"status": "Modular AI backend is running.", "modules_endpoint": "/modules", "chat_endpoint": "/chat"})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=False)
