
import os
import sys
import importlib
import inspect
import traceback

CORE_DIR = "core"
SAMPLE_INPUT = "Test input for module"

def discover_modules(core_dir):
    modules = []
    for fname in os.listdir(core_dir):
        if fname.endswith(".py") and not fname.startswith("__"):
            mod_name = fname[:-3]
            modules.append(mod_name)
    return modules

def try_import_module(module_path):
    try:
        return importlib.import_module(module_path)
    except Exception as e:
        print(f"\033[91m[ERROR] Could not import {module_path}: {e}\033[0m")
        traceback.print_exc()
        return None

def test_core_module(core_mod_name):
    # Optionally skip abstract/base modules
    if core_mod_name.lower() in ["basemodule"]:
        print(f"\033[93m[SKIP] Skipping abstract/base module: {core_mod_name}\033[0m")
        return True

    print(f"\n=== Testing core module: {core_mod_name} ===")
    mod_path = f"{CORE_DIR}.{core_mod_name}"
    mod = try_import_module(mod_path)
    if not mod:
        return False

    # Find the correct specialized class (not BaseModule)
    class_candidates = [
        attr for attr in dir(mod)
        if attr.lower().endswith("module") and attr != "BaseModule"
    ]
    if not class_candidates:
        print(f"\033[91m[ERROR] No specialized class ending with 'Module' found in {core_mod_name}\033[0m")
        return False
    cls_name = class_candidates[0]
    cls = getattr(mod, cls_name)

    # Try to instantiate with correct arguments
    try:
        sig = inspect.signature(cls.__init__)
        params = sig.parameters
        if 'working_memory' in params:
            instance = cls(shared_context={}, working_memory=None)
        else:
            instance = cls(shared_context={})
        print(f"\033[92m[OK] Instantiated {cls_name}\033[0m")
    except Exception as e:
        print(f"\033[91m[ERROR] Could not instantiate {cls_name}: {e}\033[0m")
        traceback.print_exc()
        return False

    # Test spec/routine loading
    if hasattr(instance, "specs") and isinstance(instance.specs, dict):
        print(f"\033[92m[OK] {cls_name} loaded {len(instance.specs)} specs: {list(instance.specs.keys())}\033[0m")
    elif hasattr(instance, "routines") and isinstance(instance.routines, dict):
        print(f"\033[92m[OK] {cls_name} loaded {len(instance.routines)} routines: {list(instance.routines.keys())}\033[0m")
    else:
        print(f"\033[93m[WARN] {cls_name} has no specs/routines attribute\033[0m")

    # Test process method with sample input
    try:
        result = instance.process(SAMPLE_INPUT)
        print(f"\033[92m[OK] process() output: {result}\033[0m")
    except NotImplementedError:
        print(f"\033[93m[SKIP] process() not implemented in {cls_name}\033[0m")
    except Exception as e:
        print(f"\033[91m[ERROR] process() failed: {e}\033[0m")
        traceback.print_exc()

    # Test process with a spec if available
    if hasattr(instance, "specs") and instance.specs:
        for spec_name in list(instance.specs.keys())[:1]:  # Test only the first spec for brevity
            try:
                result = instance.process(SAMPLE_INPUT, spec=spec_name)
                print(f"\033[92m[OK] process(spec='{spec_name}') output: {result}\033[0m")
            except Exception as e:
                print(f"\033[91m[ERROR] process(spec='{spec_name}') failed: {e}\033[0m")
                traceback.print_exc()

    # Test report method if available
    if hasattr(instance, "report"):
        try:
            instance.report(result={"test": "result"})
            print(f"\033[92m[OK] report() executed\033[0m")
        except Exception as e:
            print(f"\033[91m[ERROR] report() failed: {e}\033[0m")
            traceback.print_exc()

    # Test learn method if available
    if hasattr(instance, "learn"):
        try:
            instance.learn(feedback="test feedback")
            print(f"\033[92m[OK] learn() executed\033[0m")
        except Exception as e:
            print(f"\033[91m[ERROR] learn() failed: {e}\033[0m")
            traceback.print_exc()

    return True

def main():
    print("=== Modular AI Architecture Test Script ===")
    if not os.path.isdir(CORE_DIR):
        print(f"\033[91m[FATAL] Core directory '{CORE_DIR}' not found.\033[0m")
        sys.exit(1)
    modules = discover_modules(CORE_DIR)
    if not modules:
        print("\033[91m[FATAL] No core modules found.\033[0m")
        sys.exit(1)
    print(f"Discovered core modules: {modules}")

    all_ok = True
    for mod_name in modules:
        ok = test_core_module(mod_name)
        all_ok = all_ok and ok

    print("\n=== Test Complete ===")
    if all_ok:
        print("\033[92m[SUCCESS] All modules tested successfully.\033[0m")
    else:
        print("\033[93m[WARNING] Some modules failed tests. See above for details.\033[0m")

if __name__ == "__main__":
    main()
