
# main.py
from Controller import Controller
from core.WorkingMemoryManager import WorkingMemoryManager

def main():
    print("Initializing modular AI system with unified working memory...")
    # Create shared context and working memory manager
    shared_context = {}
    working_memory = WorkingMemoryManager(shared_context=shared_context)
    # Pass both to controller
    controller = Controller(shared_context=shared_context, working_memory=working_memory)
    modules = controller.list_modules()
    print("\nAll modules initialized and ready.")
    print("Available modules:", ", ".join(modules))
    print("\nUsage:")
    print(" module_name: your input")
    print(" Example: qa: What is AI?")
    print("Type 'modules' to list modules, or 'exit' to quit.\n")
    while True:
        user_input = input("> ").strip()
        if user_input.lower() in ("exit", "quit"):
            print("Exiting. Goodbye!")
            break
        elif user_input.lower() == "modules":
            print("Available modules:", ", ".join(controller.list_modules()))
        elif ":" in user_input:
            module_name, cmd = user_input.split(":", 1)
            module_name = module_name.strip()
            cmd = cmd.strip()
            result = controller.route(module_name, cmd)
            # Clean output formatting
            if isinstance(result, dict):
                print("\n--- Module Result ---")
                print(result.get("module_result"))
                print("\n--- Executive Decision ---")
                print(result.get("executive_decision"))
                print("\n--- Working Memory Snapshot ---")
                print(controller.working_memory.get_memory_snapshot())
                print("-------------------------------\n")
            else:
                print(result)
        else:
            print("Please use the format 'module_name: your input', or type 'modules' to list modules.")

if __name__ == "__main__":
    main()
