
import os
import importlib
from core.BaseModule import BaseModule

class ExecutiveFunctionModule(BaseModule):
    """
    Executive Function Module:
    - Coordinates arbitration, evaluation, and decision-making.
    - Reads from its own specs folder for routines, strategies, and parameters.
    - Can interact with other core modules via shared_context.
    """
    def __init__(self, shared_context=None, working_memory=None, specs_folder="specs/executive_function"):
        super().__init__(shared_context)
        self.name = "executive_function"
        self.eve_name = "EVE"
        self.specs_folder = specs_folder
        self.working_memory = working_memory  # <-- NEW
        self.routines = self._load_routines()

    def _load_routines(self):
        routines = {}
        if os.path.isdir(self.specs_folder):
            for fname in os.listdir(self.specs_folder):
                if fname.endswith(".py") and not fname.startswith("__"):
                    mod_name = fname[:-3]
                    try:
                        spec_module = importlib.import_module(f"specs.executive_function.{mod_name}")
                        routines[mod_name] = spec_module
                    except Exception as e:
                        print(f"Error loading executive function spec '{mod_name}': {e}")
        return routines

    def process(self, module_reports, context=None, **kwargs):
        # Input normalization: ensure module_reports is a dict
        if not isinstance(module_reports, dict):
            module_reports = {}
        # Example: Use voting.py routine if available
        if "voting" in self.routines:
            try:
                decision = self.routines["voting"].arbitrate(module_reports)
            except Exception as e:
                decision = f"Voting routine failed: {e}"
        else:
            # Fallback: pick highest confidence
            try:
                decision = max(module_reports, key=lambda k: module_reports[k].get('confidence', 0))
            except Exception:
                decision = None
        self.report(result=decision)
        return {"executive_decision": decision}

    def report(self, result=None):
        # Report to working memory if available, else to shared_context
        if self.working_memory:
            self.working_memory.add_module_output(self.name, result)
        self.shared_context["executive_function_report"] = {
            "result": result,
            "eve_name": self.eve_name
        }

    def learn(self, feedback):
        pass  # Extend as needed
