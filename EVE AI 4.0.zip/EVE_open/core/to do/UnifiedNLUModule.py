
"""
UnifiedNLUModule: Performs natural language understanding (NLU), extracting intent, entities, and keywords.
Participates in collaborative decision-making via shared_context.
Communicates directly with its corresponding specs file for NLU routines.
"""

from core.BaseModule import BaseModule
from specs.nlu.nlu_specs import (
    detect_intent, extract_key_value, extract_keywords, expand_keywords
)

class UnifiedNLUModule(BaseModule):
    def __init__(self, shared_context=None):
        super().__init__(shared_context)
        self.name = "unified_nlu"
        self.shared_context = shared_context if shared_context is not None else {}
        self._private_data = {}
        # Example intent keywords and synonyms (could be loaded from config/specs)
        self.intent_keywords = {
            "greeting": ["hello", "hi", "hey"],
            "farewell": ["bye", "goodbye", "see you"],
            "question": ["?", "what", "how", "why"]
        }
        self.synonyms = {
            "hello": ["hi", "hey"],
            "bye": ["goodbye", "see you"],
            "what": ["which", "that"],
            "how": ["in what way", "method"],
            "why": ["reason", "cause"]
        }
        self.expanded_keywords = expand_keywords(self.intent_keywords, self.synonyms)

    def process(self, user_input, context=None, **kwargs):
        last_nlp = self.shared_context.get('last_nlp')
        intent, confidence = detect_intent(user_input, self.intent_keywords, self.synonyms)
        key, value = extract_key_value(user_input)
        keywords = extract_keywords(user_input, self.expanded_keywords)
        entities = []
        if key and value:
            entities.append({"key": key, "value": value})
        self.shared_context['last_nlu'] = {
            'intent': intent,
            'confidence': confidence,
            'entities': entities,
            'keywords': keywords
        }
        self.report()
        return self.shared_context['last_nlu']

    def report(self):
        """
        Report intent and confidence to shared_context for executive decision.
        """
        intent = self.shared_context.get('last_nlu', {}).get('intent', 'unknown')
        confidence = self.shared_context.get('last_nlu', {}).get('confidence', 0.8)
        self.shared_context['nlu_report'] = {'suggestion': intent, 'confidence': confidence}

    def learn(self, feedback):
        """
        Update internal weights or parameters based on feedback.
        """
        pass
