
"""
FileSystemModule: Handles file system operations and shares results via shared_context.
Participates in collaborative decision-making and future learning/plasticity.
Communicates directly with its corresponding specs file for file system routines.
"""

from core.BaseModule import BaseModule
from specs.file_system.file_system_specs import process_file_system_command
import os
import yaml

class FileSystemModule(BaseModule):
    def __init__(self, shared_context=None):
        super().__init__(shared_context)
        self.name = "file_system"
        self.specs_folder = "specs/file_system"
        self.config_path = os.path.join(self.specs_folder, "config.yaml")
        self._ensure_specs()

    def _ensure_specs(self):
        os.makedirs(self.specs_folder, exist_ok=True)
        if not os.path.exists(self.config_path):
            with open(self.config_path, "w") as f:
                yaml.dump({"created": True}, f)

    def process(self, user_input, context=None, **kwargs):
        # Uses the actual file system logic from the specs file
        result = self._private_file_operation(user_input)
        self.shared_context['last_file_system'] = result
        self.report()
        return result

    def _private_file_operation(self, user_input):
        # Directly calls the process_file_system_command function from the specs file
        return process_file_system_command(user_input)

    def report(self):
        """
        Report file system result and confidence to shared_context for executive decision.
        """
        suggestion = self.shared_context.get('last_file_system', '')
        confidence = 0.85  # Example: could be calculated dynamically
        self.shared_context['file_system_report'] = {'suggestion': suggestion, 'confidence': confidence}

    def learn(self, feedback):
        """
        Update internal weights or parameters based on feedback.
        """
        pass
