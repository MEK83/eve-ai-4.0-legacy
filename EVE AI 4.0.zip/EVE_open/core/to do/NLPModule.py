
"""
NLPModule: Processes natural language input, extracts tokens, lemmas, keywords, and sentiment.
Participates in collaborative decision-making via shared_context.
Communicates directly with its corresponding specs files for all NLP routines.
"""

from core.BaseModule import BaseModule
from specs.nlp.tokenization import tokenize
from specs.nlp.lemmatization import lemmatize
from specs.nlp.stopwords import remove_stopwords
from specs.nlp.keywords import extract_keywords
from specs.nlp.sentiment import analyze_sentiment

class NLPModule(BaseModule):
    def __init__(self, shared_context=None):
        super().__init__(shared_context)
        self.name = "nlp"
        self.shared_context = shared_context if shared_context is not None else {}
        self._private_data = {}

    def process(self, user_input, context=None, **kwargs):
        # Tokenization (with optional stopword removal)
        stopword_set = kwargs.get("stopwords", None)
        remove_sw = kwargs.get("remove_stopwords", False)
        tokens = tokenize(user_input, remove_stopwords=remove_sw, stopwords=stopword_set)
        # Lemmatization
        lemmas = lemmatize(tokens)
        # Stopword removal (if not already done in tokenize)
        if not remove_sw:
            lemmas = remove_stopwords(lemmas)
        # Keyword extraction
        keywords = extract_keywords(lemmas)
        # Sentiment analysis
        polarity, subjectivity = analyze_sentiment(user_input)
        sentiment = {'polarity': polarity, 'subjectivity': subjectivity}
        # Save results to shared memory for other modules
        self.shared_context['last_nlp'] = {
            'tokens': tokens,
            'lemmas': lemmas,
            'keywords': keywords,
            'sentiment': sentiment
        }
        self.report()
        return self.shared_context['last_nlp']

    def report(self):
        """
        Report suggestion and confidence to shared_context for executive decision.
        """
        suggestion = self.shared_context.get('last_nlp', {}).get('keywords', [])
        confidence = 0.8  # Example: could be calculated dynamically
        self.shared_context['nlp_report'] = {'suggestion': suggestion, 'confidence': confidence}

    def learn(self, feedback):
        """
        Update internal weights or parameters based on feedback.
        """
        pass
