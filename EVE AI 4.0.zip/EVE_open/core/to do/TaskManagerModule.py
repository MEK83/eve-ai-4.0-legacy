
"""
TaskManagerModule: Handles task management and shares results via shared_context.
Participates in collaborative decision-making and future learning/plasticity.
Communicates directly with its corresponding specs file for task management routines.
"""

from core.BaseModule import BaseModule
from specs.task_manager.task_manager_specs import (
    load_tasks, save_tasks, add_task, list_tasks, complete_task, remove_task, clear_tasks
)
import os
import yaml

class TaskManagerModule(BaseModule):
    def __init__(self, shared_context=None):
        super().__init__(shared_context)
        self.name = "task_manager"
        self.specs_folder = "specs/task_manager"
        self.config_path = os.path.join(self.specs_folder, "config.yaml")
        self.tasks_path = os.path.join(self.specs_folder, "tasks.json")
        self._ensure_specs()
        # Load or initialize tasks
        self.tasks = load_tasks(self.tasks_path)

    def _ensure_specs(self):
        os.makedirs(self.specs_folder, exist_ok=True)
        if not os.path.exists(self.config_path):
            with open(self.config_path, "w") as f:
                yaml.dump({"created": True}, f)

    def process(self, user_input, context=None, **kwargs):
        # user_input can be a dict with action and parameters
        action = user_input.get("action")
        if action == "add":
            task = user_input.get("task")
            self.tasks = add_task(self.tasks, task)
            save_tasks(self.tasks, self.tasks_path)
            result = f"Task added: {task}"
        elif action == "list":
            result = list_tasks(self.tasks)
        elif action == "complete":
            idx = user_input.get("index", -1)
            self.tasks, result = complete_task(self.tasks, idx)
            save_tasks(self.tasks, self.tasks_path)
        elif action == "remove":
            idx = user_input.get("index", -1)
            self.tasks, result = remove_task(self.tasks, idx)
            save_tasks(self.tasks, self.tasks_path)
        elif action == "clear":
            self.tasks = clear_tasks()
            save_tasks(self.tasks, self.tasks_path)
            result = "All tasks cleared."
        else:
            result = "Unknown action."
        self.shared_context['last_task_manager'] = result
        self.report()
        return result

    def report(self):
        """
        Report task result and confidence to shared_context for executive decision.
        """
        suggestion = self.shared_context.get('last_task_manager', '')
        confidence = 0.85  # Example: could be calculated dynamically
        self.shared_context['task_manager_report'] = {'suggestion': suggestion, 'confidence': confidence}

    def learn(self, feedback):
        """
        Update internal weights or parameters based on feedback.
        """
        pass
