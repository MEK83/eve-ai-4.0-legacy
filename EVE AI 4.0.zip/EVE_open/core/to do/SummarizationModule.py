
"""
SummarizationModule: Handles summarization tasks and shares results via shared_context.
Participates in collaborative decision-making and future learning/plasticity.
Communicates directly with its corresponding specs file for summarization routines.
"""

from core.BaseModule import BaseModule
from specs.summarization.summarization_specs import summarize_text
import os
import yaml

class SummarizationModule(BaseModule):
    def __init__(self, shared_context=None):
        super().__init__(shared_context)
        self.name = "summarization"
        self.specs_folder = "specs/summarization"
        self.config_path = os.path.join(self.specs_folder, "config.yaml")
        self._ensure_specs()

    def _ensure_specs(self):
        os.makedirs(self.specs_folder, exist_ok=True)
        if not os.path.exists(self.config_path):
            with open(self.config_path, "w") as f:
                yaml.dump({"created": True}, f)

    def process(self, user_input, context=None, **kwargs):
        # Uses the actual summarization logic from the specs file
        file_content = kwargs.get("file_content", "")
        result = summarize_text(user_input, file_content)
        self.shared_context['last_summarization'] = result
        self.report()
        return result

    def report(self):
        """
        Report summary result and confidence to shared_context for executive decision.
        """
        suggestion = self.shared_context.get('last_summarization', '')
        confidence = 0.9  # Example: could be calculated dynamically
        self.shared_context['summarization_report'] = {'suggestion': suggestion, 'confidence': confidence}

    def learn(self, feedback):
        """
        Update internal weights or parameters based on feedback.
        """
        pass
