
"""
SmartMemoryModule: Handles memory-related tasks and shares results via shared_context.
Participates in collaborative decision-making and future learning/plasticity.
Communicates directly with its corresponding specs file for memory routines.
"""

from core.BaseModule import BaseModule
from specs.memory.memory_specs import (
    load_memory, save_memory, remember, recall, memory_stats, prune_expired
)
import os
import yaml

class SmartMemoryModule(BaseModule):
    def __init__(self, shared_context=None):
        super().__init__(shared_context)
        self.name = "memory"
        self.specs_folder = "specs/memory"
        self.config_path = os.path.join(self.specs_folder, "config.yaml")
        self.memory_path = os.path.join(self.specs_folder, "memory.json")
        self._ensure_specs()
        # Load or initialize memory
        self.facts = load_memory(self.memory_path)

    def _ensure_specs(self):
        os.makedirs(self.specs_folder, exist_ok=True)
        if not os.path.exists(self.config_path):
            with open(self.config_path, "w") as f:
                yaml.dump({"created": True}, f)

    def process(self, user_input, context=None, **kwargs):
        # Example: user_input = {"action": "remember", ...}
        action = user_input.get("action")
        if action == "remember":
            key = user_input.get("key")
            value = user_input.get("value")
            tags = user_input.get("tags", [])
            max_size = user_input.get("max_size", 100)
            self.facts = remember(self.facts, key, value, tags, max_size, self.memory_path)
            result = f"Remembered: {key}"
        elif action == "recall":
            query = user_input.get("query")
            result = recall(self.facts, query, self.memory_path)
        elif action == "stats":
            result = memory_stats(self.facts)
        elif action == "prune_expired":
            expiry_time = user_input.get("expiry_time", 3600)
            self.facts = prune_expired(self.facts, expiry_time)
            save_memory(self.facts, self.memory_path)
            result = "Expired facts pruned."
        else:
            result = "Unknown action."
        self.shared_context['last_memory'] = result
        self.report()
        return result

    def report(self):
        """
        Report memory result and confidence to shared_context for executive decision.
        """
        suggestion = self.shared_context.get('last_memory', '')
        confidence = 0.85  # Example: could be calculated dynamically
        self.shared_context['memory_report'] = {'suggestion': suggestion, 'confidence': confidence}

    def learn(self, feedback):
        """
        Update internal weights or parameters based on feedback.
        """
        pass
