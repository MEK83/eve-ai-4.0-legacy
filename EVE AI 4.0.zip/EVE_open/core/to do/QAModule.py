
"""
QAModule: Handles question answering tasks and shares results via shared_context.
Participates in collaborative decision-making and future learning/plasticity.
Communicates directly with its corresponding specs file for QA routines.
"""

from core.BaseModule import BaseModule
from specs.qa.qa_specs import fallback_qa, file_based_qa
import os
import yaml

class QAModule(BaseModule):
    def __init__(self, shared_context=None):
        super().__init__(shared_context)
        self.name = "qa"
        self.specs_folder = "specs/qa"
        self.config_path = os.path.join(self.specs_folder, "config.yaml")
        self._ensure_specs()

    def _ensure_specs(self):
        os.makedirs(self.specs_folder, exist_ok=True)
        if not os.path.exists(self.config_path):
            with open(self.config_path, "w") as f:
                yaml.dump({"created": True}, f)

    def process(self, user_input, context=None, **kwargs):
        # Use the actual QA logic from the specs file
        file_content = kwargs.get("file_content", None)
        if file_content:
            result = file_based_qa(user_input, file_content)
        else:
            result = fallback_qa(user_input)
        self.shared_context['last_qa'] = result
        self.report()
        return result

    def report(self):
        """
        Report QA result and confidence to shared_context for executive decision.
        """
        suggestion = self.shared_context.get('last_qa', '')
        confidence = 0.9  # Example: could be calculated dynamically
        self.shared_context['qa_report'] = {'suggestion': suggestion, 'confidence': confidence}

    def learn(self, feedback):
        """
        Update internal weights or parameters based on feedback.
        """
        pass
