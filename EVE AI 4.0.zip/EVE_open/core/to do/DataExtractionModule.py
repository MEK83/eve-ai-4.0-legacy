
"""
DataExtractionModule: Handles data extraction tasks and shares results via shared_context.
Participates in collaborative decision-making and future learning/plasticity.
Communicates directly with its corresponding specs file for extraction routines.
"""

from core.BaseModule import BaseModule
from specs.data_extraction.data_extraction_specs import extract_all
import os
import yaml

class DataExtractionModule(BaseModule):
    def __init__(self, shared_context=None):
        super().__init__(shared_context)
        self.name = "data_extraction"
        self.specs_folder = "specs/data_extraction"
        self.config_path = os.path.join(self.specs_folder, "config.yaml")
        self._ensure_specs()

    def _ensure_specs(self):
        os.makedirs(self.specs_folder, exist_ok=True)
        if not os.path.exists(self.config_path):
            with open(self.config_path, "w") as f:
                yaml.dump({"created": True}, f)

    def process(self, user_input, context=None, **kwargs):
        # Uses the actual extraction logic from the specs file
        result = self._private_data_extraction(user_input)
        self.shared_context['last_data_extraction'] = result
        self.report()
        return result

    def _private_data_extraction(self, user_input):
        # Directly calls the extract_all function from the specs file
        return extract_all(user_input)

    def report(self):
        """
        Report data extraction result and confidence to shared_context for executive decision.
        """
        suggestion = self.shared_context.get('last_data_extraction', '')
        confidence = 0.9  # Example: could be calculated dynamically
        self.shared_context['data_extraction_report'] = {'suggestion': suggestion, 'confidence': confidence}

    def learn(self, feedback):
        """
        Update internal weights or parameters based on feedback.
        """
        pass
