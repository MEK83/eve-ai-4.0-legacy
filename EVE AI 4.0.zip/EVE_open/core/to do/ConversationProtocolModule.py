
"""
ConversationProtocolModule: Manages conversation history, tone, and response generation.
Participates in collaborative decision-making via shared_context.
Communicates directly with its corresponding specs file for conversation routines.
"""

from core.BaseModule import BaseModule
import os
from specs.conversation_protocol.conversation_protocol_specs import (
    generate_response,
    manage_history,
    summarize_conversation,
    set_tone
)

class ConversationProtocolModule(BaseModule):
    def __init__(self, shared_context=None):
        self.name = "conversation_protocol"
        self.specs_folder = "specs/conversation_protocol"
        self.shared_context = shared_context if shared_context is not None else {}
        self.history = self.shared_context.setdefault('conversation_history', [])
        self.tone = self.shared_context.get('tone', 'friendly')

    def initialize(self):
        print(f"{self.name} core module initialized. Specs folder ready.")

    def process(self, user_input, context=None, **kwargs):
        # Accept action as a keyword argument, default to "generate"
        action = kwargs.get("action", "generate")
        if action == "generate":
            response = generate_response(user_input, self.tone, self.history)
            self.history.append({
                "user": user_input,
                "vai": response,
                "time": "now"  # Replace with actual timestamp if needed
            })
            self.shared_context['last_conversation'] = response
            self.report()
            return {
                "response": response,
                "history": self.history,
                "shared_context": self.shared_context
            }
        elif action == "summarize":
            summary = summarize_conversation(self.history)
            return {"summary": summary}
        elif action == "set_tone":
            result = set_tone(user_input, ["friendly", "professional", "cheerful"])
            self.tone = user_input if "set to" in result else self.tone
            self.shared_context['tone'] = self.tone
            return {"result": result}
        elif action == "manage_history":
            result = manage_history(self.history, user_input)
            return {"result": result}
        else:
            return {"error": "Unknown action."}

    def get_last_conversation(self):
        return self.shared_context.get('last_conversation', None)

    def get_history(self):
        return self.history

    def report(self):
        """
        Report conversation summary and confidence to shared_context for executive decision.
        """
        summary = self.shared_context.get('last_conversation', '')
        confidence = 0.9  # Example: could be calculated dynamically
        self.shared_context['conversation_report'] = {'suggestion': summary, 'confidence': confidence}

    def learn(self, feedback):
        """
        Update internal weights or parameters based on feedback.
        """
        pass
