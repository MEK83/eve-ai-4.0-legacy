
"""
FullTextSearchModule: Handles full-text search tasks and shares results via shared_context.
Participates in collaborative decision-making and future learning/plasticity.
Communicates directly with its corresponding specs file for search routines.
"""

from core.BaseModule import BaseModule
from specs.full_text_search.text_search_specs import search_in_text, add_search_history, get_recent_searches
import os
import yaml

class FullTextSearchModule(BaseModule):
    def __init__(self, shared_context=None):
        super().__init__(shared_context)
        self.name = "full_text_search"
        self.specs_folder = "specs/full_text_search"
        self.config_path = os.path.join(self.specs_folder, "config.yaml")
        self._ensure_specs()
        # Initialize search history in shared context if not present
        if 'search_history' not in self.shared_context:
            self.shared_context['search_history'] = []

    def _ensure_specs(self):
        os.makedirs(self.specs_folder, exist_ok=True)
        if not os.path.exists(self.config_path):
            with open(self.config_path, "w") as f:
                yaml.dump({"created": True}, f)

    def process(self, user_input, context=None, **kwargs):
        # Use the actual search logic from the specs file
        file_content = kwargs.get('file_content', '')
        snippets, count = self._private_search(user_input, file_content)
        # Update search history
        self.shared_context['search_history'] = add_search_history(user_input, self.shared_context['search_history'])
        result = {
            "query": user_input,
            "snippets": snippets,
            "count": count,
            "recent_searches": get_recent_searches(self.shared_context['search_history'])
        }
        self.shared_context['last_full_text_search'] = result
        self.report()
        return result

    def _private_search(self, user_input, file_content):
        # Directly calls the search_in_text function from the specs file
        return search_in_text(user_input, file_content)

    def report(self):
        """
        Report full-text search result and confidence to shared_context for executive decision.
        """
        suggestion = self.shared_context.get('last_full_text_search', '')
        confidence = 0.9  # Example: could be calculated dynamically
        self.shared_context['full_text_search_report'] = {'suggestion': suggestion, 'confidence': confidence}

    def learn(self, feedback):
        """
        Update internal weights or parameters based on feedback.
        """
        pass
