
import os
import importlib
from core.BaseModule import BaseModule

class PersonalityModule(BaseModule):
    def __init__(self, shared_context=None, working_memory=None, specs_folder="specs/personality"):
        super().__init__(shared_context)
        self.name = "personality"
        self.eve_name = "EVE"
        self.specs_folder = specs_folder
        self.specs = {}
        self.current_profile = "casual"
        self.working_memory = working_memory  # <-- NEW
        self._load_specs()

    def _load_specs(self):
        specs_path = os.path.abspath(self.specs_folder)
        if not os.path.exists(specs_path):
            os.makedirs(specs_path)
        for fname in os.listdir(specs_path):
            if fname.endswith(".py") and not fname.startswith("__"):
                spec_name = fname[:-3]
                try:
                    module = importlib.import_module(f"specs.personality.{spec_name}")
                    self.specs[spec_name] = module
                except Exception as e:
                    print(f"Error loading personality spec '{spec_name}': {e}")

    def process(self, user_input, spec=None, **kwargs):
        # Input normalization: always pass a dict to specs
        if isinstance(user_input, str):
            user_input = {"text": user_input}
        # Log input to working memory if available
        if self.working_memory:
            self.working_memory.add_input(user_input)
        if spec and spec in self.specs:
            try:
                result = self.specs[spec].run(
                    user_input,
                    shared_context=self.shared_context,
                    current_profile=self.current_profile,
                    **kwargs
                )
                self.report(result=result)
                return result
            except Exception as e:
                return {"error": f"Spec '{spec}' failed: {e}"}
        else:
            results = {}
            for spec_name, module in self.specs.items():
                try:
                    results[spec_name] = module.run(
                        user_input,
                        shared_context=self.shared_context,
                        current_profile=self.current_profile,
                        **kwargs
                    )
                except Exception as e:
                    results[spec_name] = {"error": str(e)}
            self.report(result=results)
            return results

    def report(self, result=None):
        # Report to working memory if available, else to shared_context
        if self.working_memory:
            self.working_memory.add_module_output(self.name, result, confidence=0.85)
        self.shared_context["personality_report"] = {
            "suggestion": result,
            "confidence": 0.85,
            "eve_name": self.eve_name
        }

    def learn(self, feedback):
        pass  # Placeholder for future learning logic
