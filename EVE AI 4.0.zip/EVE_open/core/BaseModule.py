
# core/BaseModule.py

class BaseModule:
    """
    Base class for all core modules.
    - Provides shared_context for inter-module communication.
    - Enforces a standard interface for all modules.
    - Private routines and data should be implemented in subclasses.
    """

    def __init__(self, shared_context=None):
        # Shared memory for communication between modules
        self.shared_context = shared_context if shared_context is not None else {}

    def process(self, user_input, **kwargs):
        """
        Main method to process user input.
        Must be overridden by child modules.
        :param user_input: str, the input from the user or another module
        :param kwargs: additional arguments for flexibility
        :return: dict, result of processing
        """
        raise NotImplementedError("Each module must implement the process() method.")

    # Optional: For modules that want to support learning or adaptation
    def reinforce(self):
        """Optional method for reinforcement learning or adaptation."""
        pass

    def tweak(self):
        """Optional method for tweaking module behavior."""
        pass
