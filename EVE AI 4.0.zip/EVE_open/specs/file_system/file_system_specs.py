
import os

def read_file(file_path):
    """
    Reads the content of a file if it exists.
    Returns: content (str) or error message (str)
    """
    if os.path.isfile(file_path):
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                return f.read()
        except Exception as e:
            return f"File error: {e}"
    else:
        return "File not found."

def list_files(directory="."):
    """
    Lists files in the specified directory.
    Returns: list of filenames (list of str)
    """
    try:
        return os.listdir(directory)
    except Exception as e:
        return [f"Directory error: {e}"]

def process_file_system_command(user_input):
    """
    Processes file system commands: file read or list files.
    Returns: result (str)
    """
    if os.path.isfile(user_input):
        return read_file(user_input)
    elif user_input.lower().startswith("list files"):
        files = list_files()
        return "Files: " + ", ".join(files)
    else:
        return "Command not recognized by file_system."


def run(input, **kwargs):
    return {"error": "Not implemented yet"}
