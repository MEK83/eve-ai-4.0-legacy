
import json
import os
import time

def load_tasks(file_path):
    if os.path.exists(file_path):
        with open(file_path, "r", encoding="utf-8") as f:
            return json.load(f)
    return []

def save_tasks(tasks, file_path):
    with open(file_path, "w", encoding="utf-8") as f:
        json.dump(tasks, f, indent=2)

def add_task(tasks, task):
    tasks.append({
        "task": task,
        "done": False,
        "created": time.strftime("%Y-%m-%d %H:%M:%S")
    })
    return tasks

def list_tasks(tasks):
    if not tasks:
        return "No tasks found."
    lines = []
    for idx, t in enumerate(tasks, 1):
        status = "✅" if t["done"] else "❌"
        lines.append(f"{idx}. {t['task']} {status}")
    return "Your tasks:\n" + "\n".join(lines)

def complete_task(tasks, idx):
    if 0 <= idx < len(tasks):
        tasks[idx]["done"] = True
        return tasks, f"Task marked as complete: {tasks[idx]['task']}"
    else:
        return tasks, "Task number out of range."

def remove_task(tasks, idx):
    if 0 <= idx < len(tasks):
        removed = tasks.pop(idx)
        return tasks, f"Task removed: {removed['task']}"
    else:
        return tasks, "Task number out of range."

def clear_tasks():
    return []


def run(input, **kwargs):
    return {"error": "Not implemented yet"}
