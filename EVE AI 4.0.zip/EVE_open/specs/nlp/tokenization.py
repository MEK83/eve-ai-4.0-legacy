
import re

def tokenize(text, remove_stopwords=False, stopwords=None):
    """
    Splits text into clean, lowercase tokens.
    Handles punctuation, contractions, and optionally removes stopwords.
    Returns a list of tokens.
    """
    tokens = re.findall(r"\b\w[\w']*\b", text.lower())
    if remove_stopwords and stopwords is not None:
        tokens = [token for token in tokens if token not in stopwords]
    return tokens


def run(input, **kwargs):
    return {"error": "Not implemented yet"}
