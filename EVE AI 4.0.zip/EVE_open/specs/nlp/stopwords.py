
def remove_stopwords(tokens, stopwords=None):
    """Removes common stopwords from a list of tokens."""
    if stopwords is None:
        # Minimal English stopword list; expand as needed
        stopwords = {'the', 'is', 'at', 'which', 'on', 'and', 'a', 'an', 'of', 'to', 'in'}
    return [token for token in tokens if token not in stopwords]


def run(input, **kwargs):
    return {"error": "Not implemented yet"}
