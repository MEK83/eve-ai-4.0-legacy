
def lemmatize(tokens):
    """Dummy lemmatizer: returns tokens unchanged. Replace with real lemmatizer if needed."""
    return tokens
# For real lemmatization, use libraries like spaCy or NLTK.


def run(input, **kwargs):
    return {"error": "Not implemented yet"}
