
from collections import Counter

def extract_keywords(tokens, top_n=5):
    """Returns the most frequent tokens as keywords."""
    freq = Counter(tokens)
    return [word for word, count in freq.most_common(top_n)]


def run(input, **kwargs):
    return {"error": "Not implemented yet"}
