
from textblob import TextBlob

def analyze_sentiment(text):
    """Returns polarity and subjectivity scores."""
    blob = TextBlob(text)
    return blob.sentiment.polarity, blob.sentiment.subjectivity


def run(input, **kwargs):
    return {"error": "Not implemented yet"}
