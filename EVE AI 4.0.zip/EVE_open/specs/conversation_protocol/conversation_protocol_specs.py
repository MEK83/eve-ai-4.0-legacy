
import random
import time
import json
import os

# --- Response Generation ---
def generate_response(user_input, tone, history, generator=None):
    """
    Generate a conversational response using a model (if available) and tone templates.
    Returns: response string.
    """
    templates = {
        "friendly": [
            "Sure thing! {response}",
            "Got it 😊 {response}",
            "Alright! {response}. Anything else?"
        ],
        "professional": [
            "Understood. {response}",
            "Acknowledged: {response}",
            "Confirmed. {response}. How can I assist further?"
        ],
        "cheerful": [
            "Awesome! {response} 🎉",
            "Great news! {response}",
            "Fantastic! {response}. What’s next?"
        ]
    }
    starters = [
        "Here's what I found:",
        "Let me check that for you...",
        "Great question!",
        "Thanks for sharing that.",
        "Just to confirm,"
    ]
    follow_ups = [
        "Anything else you'd like to know?",
        "Is there something else I can help with?",
        "Feel free to ask me anything!",
        "Let me know if you need more details."
    ]
    # Generate AI response
    if generator:
        try:
            response_list = generator(user_input, max_new_tokens=100, pad_token_id=50256)
            ai_response = response_list[0]['generated_text'] if response_list else ""
        except Exception as e:
            ai_response = f"(Sorry, I had trouble generating a response: {e})"
    else:
        ai_response = "(AI model not available. Please check your installation.)"
    # Compose final output
    starter = random.choice(starters)
    template = random.choice(templates.get(tone, templates["friendly"]))
    follow_up = random.choice(follow_ups)
    conversational_response = f"{starter} {template.format(response=ai_response)} {follow_up}"
    return conversational_response

# --- History Management ---
def manage_history(history, action, file_path="conversation_history.json"):
    """
    Manage conversation history: reset, show, export.
    Returns: result string or updated history.
    """
    if action == "reset":
        history.clear()
        save_history(history, file_path)
        return "Conversation history reset."
    elif action == "show":
        return format_history(history)
    elif action == "export":
        save_history(history, file_path)
        return f"Conversation exported to {file_path}"
    else:
        return "Unknown action."

def save_history(history, file_path):
    """
    Save conversation history to file.
    """
    try:
        with open(file_path, "w", encoding="utf-8") as f:
            json.dump(history, f, indent=2)
    except Exception as e:
        print(f"Warning: Could not save history file: {e}")

def format_history(history):
    """
    Format last 10 turns of conversation history.
    Returns: formatted string.
    """
    if not history:
        return "No conversation history."
    lines = []
    for turn in history[-10:]:
        lines.append(f"[{turn.get('time', 'unknown')}] You: {turn.get('user', '')}")
        lines.append(f"[{turn.get('time', 'unknown')}] VAI: {turn.get('vai', '')}")
    return "\n".join(lines)

# --- Summarization ---
def summarize_conversation(history):
    """
    Summarize recent conversation turns.
    Returns: summary string.
    """
    if not history:
        return "No conversation history to summarize."
    summary_lines = []
    for turn in history[-5:]:
        summary_lines.append(f"[{turn.get('time', 'unknown')}] You: {turn.get('user', '')}")
        summary_lines.append(f"[{turn.get('time', 'unknown')}] VAI: {turn.get('vai', '')}")
    return "Recent conversation summary:\n" + "\n".join(summary_lines)

# --- Tone Management ---
def set_tone(tone, available_tones):
    """
    Set the conversation tone if available.
    Returns: result string.
    """
    if tone in available_tones:
        return f"Tone set to {tone}."
    else:
        return f"Tone '{tone}' not recognized. Available: {', '.join(available_tones)}"


def run(input, **kwargs):
    return {"error": "Not implemented yet"}
