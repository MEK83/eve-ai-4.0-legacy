
import time
import json
import os

def load_memory(file_path):
    if os.path.exists(file_path):
        with open(file_path, "r", encoding="utf-8") as f:
            return json.load(f)
    return {}

def save_memory(facts, file_path):
    with open(file_path, "w", encoding="utf-8") as f:
        json.dump(facts, f)

def levenshtein(s1, s2):
    if len(s1) < len(s2):
        return levenshtein(s2, s1)
    if len(s2) == 0:
        return len(s1)
    previous_row = range(len(s2) + 1)
    for i, c1 in enumerate(s1):
        current_row = [i + 1]
        for j, c2 in enumerate(s2):
            insertions = previous_row[j + 1] + 1
            deletions = current_row[j] + 1
            substitutions = previous_row[j] + (c1 != c2)
            current_row.append(min(insertions, deletions, substitutions))
        previous_row = current_row
    return previous_row[-1]

def prune_expired(facts, expiry_time):
    now = time.time()
    expired_keys = [k for k, v in facts.items() if now - v["last_accessed"] > expiry_time]
    for k in expired_keys:
        del facts[k]
    return facts

def prune_least_used(facts):
    if facts:
        least_used = sorted(facts.items(), key=lambda item: item[1]["access_count"])
        del facts[least_used[0][0]]
    return facts

def remember(facts, key, value, tags=None, max_size=100, file_path=None):
    if len(facts) >= max_size:
        facts = prune_least_used(facts)
    facts[key] = {
        "value": value,
        "last_accessed": time.time(),
        "access_count": 1,
        "tags": tags or []
    }
    if file_path:
        save_memory(facts, file_path)
    return facts

def recall(facts, query, file_path=None):
    # Try exact, substring, then fuzzy match
    for k in facts:
        if query.lower() == k.lower():
            facts[k]["last_accessed"] = time.time()
            facts[k]["access_count"] += 1
            if file_path:
                save_memory(facts, file_path)
            return facts[k]["value"]
    for k in facts:
        if query.lower() in k.lower():
            facts[k]["last_accessed"] = time.time()
            facts[k]["access_count"] += 1
            if file_path:
                save_memory(facts, file_path)
            return facts[k]["value"]
    for k in facts:
        if levenshtein(query.lower(), k.lower()) <= 2:
            facts[k]["last_accessed"] = time.time()
            facts[k]["access_count"] += 1
            if file_path:
                save_memory(facts, file_path)
            return facts[k]["value"]
    return None

def memory_stats(facts):
    return f"Stored facts: {len(facts)}"


def run(input, **kwargs):
    return {"error": "Not implemented yet"}
