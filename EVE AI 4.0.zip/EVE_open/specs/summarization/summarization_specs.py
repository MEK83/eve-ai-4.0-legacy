
from textblob import TextBlob

def summarize_text(user_input, file_content):
    """
    Summarizes file content based on keywords in user_input.
    """
    if user_input.lower().startswith("summarize"):
        if not file_content:
            return "No file loaded to summarize."
        blob = TextBlob(file_content)
        sentences = blob.sentences
        keywords = set(user_input.lower().replace("summarize", "").split())
        scored = []
        for s in sentences:
            score = len(s.words)
            if keywords:
                score += sum(1 for w in s.words if w.lower() in keywords)
            scored.append((score, str(s)))
        summary_sentences = [s for _, s in sorted(scored, reverse=True)[:3]]
        summary = " ".join(summary_sentences)
        return f"Summary: {summary}"
    elif user_input.lower().startswith("summary length:"):
        try:
            n = int(user_input.split(":", 1)[1].strip())
            if not file_content:
                return "No file loaded to summarize."
            blob = TextBlob(file_content)
            sentences = blob.sentences
            summary = " ".join(str(s) for s in sentences[:n])
            return f"Summary: {summary}"
        except Exception:
            return "Invalid summary length command."
    return "Command not recognized by summarization."


def run(input, **kwargs):
    return {"error": "Not implemented yet"}
