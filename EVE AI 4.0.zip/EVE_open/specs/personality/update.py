
# specs/personality/update.py


def run(input, **kwargs):
    # Handle string input
    if isinstance(input, str):
        text = input
    # Handle dict input with 'text' key
    elif isinstance(input, dict):
        text = input.get('text', '')
    # Handle list input (optional: join or process each item)
    elif isinstance(input, list):
        # If list of dicts with 'text', join them
        if all(isinstance(i, dict) and 'text' in i for i in input):
            text = ' '.join(i['text'] for i in input)
        else:
            text = str(input)
    else:
        return {"error": f"Unsupported input type: {type(input)}"}

    # Now text is always a string
    try:
        # Replace with your actual logic if needed
        return text.lower()
    except Exception as e:
        return {"error": str(e)}