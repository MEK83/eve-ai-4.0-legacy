
from difflib import get_close_matches
from specs.nlp.tokenization import tokenize

def expand_keywords(intent_keywords, synonyms):
    """
    Expands intent keywords with their synonyms.
    Returns a dict mapping intent to a set of keywords.
    """
    expanded = {}
    for intent, keywords in intent_keywords.items():
        expanded[intent] = set(keywords)
        for kw in keywords:
            expanded[intent].update(synonyms.get(kw, []))
    return expanded

def detect_intent(user_input, intent_keywords, synonyms):
    """
    Detects intent from user input using expanded keywords and fuzzy matching.
    Returns (intent, confidence).
    """
    expanded_keywords = expand_keywords(intent_keywords, synonyms)
    detected_intent = "unknown"
    confidence = 0.0
    tokens = tokenize(user_input)
    input_text = " ".join(tokens)
    for intent, keywords in expanded_keywords.items():
        matches = [kw for kw in keywords if kw in input_text]
        if matches:
            detected_intent = intent
            confidence = len(matches) / len(keywords)
            break
    if detected_intent == "unknown":
        all_keywords = [kw for kws in expanded_keywords.values() for kw in kws]
        fuzzy_matches = get_close_matches(input_text, all_keywords, n=1, cutoff=0.8)
        if fuzzy_matches:
            for intent, keywords in expanded_keywords.items():
                if fuzzy_matches[0] in keywords:
                    detected_intent = intent
                    confidence = 0.7
                    break
    return detected_intent, confidence

def extract_key_value(user_input):
    """
    Extracts key-value pairs from input like 'my X is Y'.
    Returns (key, value) or (None, None) if not found.
    """
    tokens = tokenize(user_input)
    if "my" in tokens and "is" in tokens:
        try:
            idx_my = tokens.index("my")
            idx_is = tokens.index("is")
            key = tokens[idx_my + 1] if idx_my + 1 < len(tokens) else None
            value = tokens[idx_is + 1] if idx_is + 1 < len(tokens) else None
            if key and value:
                return key, value
        except (ValueError, IndexError):
            pass
    return None, None

def extract_keywords(user_input, expanded_keywords):
    """
    Extracts non-intent keywords from user input using advanced tokenization.
    Returns a list of keywords.
    """
    all_intent_keywords = set(kw for kws in expanded_keywords.values() for kw in kws)
    tokens = tokenize(user_input)
    return [w for w in set(tokens) if w.isalpha() and w not in all_intent_keywords]


def run(input, **kwargs):
    return {"error": "Not implemented yet"}
