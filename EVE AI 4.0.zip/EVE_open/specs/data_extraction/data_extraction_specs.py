
import re

def extract_dates(text):
    """
    Extract dates in formats like DD/MM/YYYY or DD-MM-YYYY.
    Returns: list of date strings.
    """
    return re.findall(r"\b\d{1,2}[/\-]\d{1,2}[/\-]\d{2,4}\b", text)

def extract_emails(text):
    """
    Extract email addresses.
    Returns: list of email strings.
    """
    return re.findall(r"[a-zA-Z0-9_.+\-]+@[a-zA-Z0-9\-]+\.[a-zA-Z0-9\-.]+", text)

def extract_numbers(text):
    """
    Extract standalone numbers.
    Returns: list of number strings.
    """
    return re.findall(r"\b\d+\b", text)

def extract_all(text):
    """
    Extract dates, emails, and numbers from text.
    Returns: dict with keys 'dates', 'emails', 'numbers'.
    """
    return {
        "dates": extract_dates(text),
        "emails": extract_emails(text),
        "numbers": extract_numbers(text)
    }


def run(input, **kwargs):
    return {"error": "Not implemented yet"}
