
# specs/speech/language_model_mistral_specs.py

def generate_response(
    prompt,
    context=None,
    model_name="mistralai/Mistral-7B-Instruct-v0.2",
    temperature=0.7,
    max_tokens=128
):
    """
    Generates a conversational response using the free Mistral-7B-Instruct model from HuggingFace.
    Uses GPU (CUDA) if available, otherwise falls back to CPU.
    """
    try:
        from transformers import AutoModelForCausalLM, AutoTokenizer, pipeline
        import torch
    except ImportError:
        return "Transformers or torch library not found. Please install with: pip install transformers torch"

    # Detect device
    device = 0 if torch.cuda.is_available() else -1

    # Load model and tokenizer (downloads automatically if not present)
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    model = AutoModelForCausalLM.from_pretrained(model_name)

    # Build prompt (add context if provided)
    full_prompt = prompt
    if context:
        full_prompt = f"{context}\n{prompt}"

    # Use pipeline for text generation
    generator = pipeline(
        "text-generation",
        model=model,
        tokenizer=tokenizer,
        device=device  # 0 = first GPU, -1 = CPU
    )
    output = generator(
        full_prompt,
        max_length=max_tokens,
        temperature=temperature,
        do_sample=True,
        truncation=True  # Ensures prompt fits model context window
    )
    # Return only the generated part, not the prompt
    return output[0]['generated_text'][len(full_prompt):].strip()


def run(input, **kwargs):
    return {"error": "Not implemented yet"}
