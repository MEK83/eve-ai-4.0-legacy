
import re

def search_in_text(query, file_content):
    """
    Fuzzy, case-insensitive search for query in file_content.
    Returns: (found_snippets, count) or (None, 0) if not found.
    """
    if not file_content:
        return None, 0
    pattern = re.compile(re.escape(query), re.IGNORECASE)
    matches = list(pattern.finditer(file_content))
    if matches:
        snippets = []
        for m in matches[:3]:  # Show up to 3 context snippets
            start = max(0, m.start() - 30)
            end = min(len(file_content), m.end() + 30)
            snippet = file_content[start:end].replace('\n', ' ')
            snippet = snippet.replace(query, f"**{query}**")
            snippets.append(snippet)
        return snippets, len(matches)
    else:
        return None, 0

def add_search_history(query, search_history):
    """
    Append query to search history.
    Returns: updated search_history (list)
    """
    search_history.append(query)
    return search_history

def get_recent_searches(search_history, n=5):
    """
    Returns the last n search queries.
    """
    if search_history:
        return search_history[-n:]
    else:
        return []


def run(input, **kwargs):
    return {"error": "Not implemented yet"}
