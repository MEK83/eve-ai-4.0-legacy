
# specs/executive_function/meta_learning.py

def update_strategy_performance(strategy_name, outcome, performance_log):
    """
    Track which arbitration strategies perform best.
    Accepts performance_log as dict or string.
    outcome: e.g., 'success', 'failure', or a numeric score.
    """

    # --- Universal input-handling pattern ---
    if isinstance(performance_log, dict):
        log = performance_log
    elif isinstance(performance_log, str):
        # If string, treat as a single strategy log
        log = {strategy_name: [performance_log]}
    else:
        log = {}

    if strategy_name not in log:
        log[strategy_name] = []
    log[strategy_name].append(outcome)
    return log

def best_strategy(performance_log):
    """
    Return the strategy with the best average outcome.
    Accepts performance_log as dict or string.
    """

    # --- Universal input-handling pattern ---
    if isinstance(performance_log, dict):
        log = performance_log
    elif isinstance(performance_log, str):
        # If string, treat as a single strategy log
        log = {"default": [performance_log]}
    else:
        log = {}

    if not log:
        return None

    # Example: choose strategy with most 'success' outcomes
    best = max(log.items(), key=lambda item: item[1].count('success'))
    return best[0]


def run(input, **kwargs):
    return {"error": "Not implemented yet"}
