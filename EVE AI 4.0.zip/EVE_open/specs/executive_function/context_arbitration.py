
# specs/executive_function/context_arbitration.py

def resolve_context_conflicts(shared_context, new_updates):
    """
    Merge or prioritize context updates from different modules.
    Accepts shared_context and new_updates as dict or string.
    """

    # --- Universal input-handling pattern ---
    # Normalize shared_context
    if isinstance(shared_context, dict):
        context = shared_context
    elif isinstance(shared_context, str):
        # If string, treat as a single key-value update (customize as needed)
        context = {"context": shared_context}
    else:
        context = {}

    # Normalize new_updates
    if isinstance(new_updates, dict):
        updates = new_updates
    elif isinstance(new_updates, str):
        updates = {"update": new_updates}
    else:
        updates = {}

    # --- Simple merge (last update wins) ---
    context.update(updates)
    return context


def run(input, **kwargs):
    return {"error": "Not implemented yet"}
