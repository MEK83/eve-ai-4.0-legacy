
# specs/executive_function/error_handling.py

def handle_module_error(module_name, error, module_reports):
    """
    Penalize or remove modules that error out, fallback to next-best suggestion.
    Accepts module_reports as dict, string, or list.
    """

    # --- Universal input-handling pattern ---
    if isinstance(module_reports, dict):
        reports = {k: v for k, v in module_reports.items() if k != module_name}
    elif isinstance(module_reports, str):
        # If string, treat as a single report (ignore errored module)
        reports = {} if module_name in module_reports else {"report": module_reports}
    elif isinstance(module_reports, list):
        # Remove errored module if present in list
        reports = [r for r in module_reports if r != module_name]
    else:
        reports = {}

    if not reports:
        return {"winning_suggestion": None, "reason": "All modules failed."}

    # Fallback to voting
    from . import voting
    return voting.arbitrate(reports)


def run(input, **kwargs):
    return {"error": "Not implemented yet"}
