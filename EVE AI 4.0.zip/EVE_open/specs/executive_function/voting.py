
# specs/executive_function/voting.py

def arbitrate(module_reports):
    """
    Selects the suggestion with the highest total confidence.
    Accepts module_reports as dict, string, or list.
    Returns the winning suggestion and supporting details.
    """

    # --- Universal input-handling pattern ---
    if isinstance(module_reports, dict):
        reports = module_reports
    elif isinstance(module_reports, str):
        # If string, treat as a single suggestion with default confidence
        reports = {"default": {"suggestion": module_reports, "confidence": 1.0}}
    elif isinstance(module_reports, list):
        # If list, convert to dict with default keys
        reports = {f"module_{i}": {"suggestion": r, "confidence": 1.0} for i, r in enumerate(module_reports)}
    else:
        reports = {}

    votes = {}
    for mod, report in reports.items():
        suggestion = report.get('suggestion')
        confidence = report.get('confidence', 0)
        if suggestion is not None:
            votes[suggestion] = votes.get(suggestion, 0) + confidence

    if not votes:
        return {"winning_suggestion": None, "reason": "No suggestions found."}

    winning_suggestion = max(votes, key=votes.get)
    return {
        "winning_suggestion": winning_suggestion,
        "winning_confidence": votes[winning_suggestion],
        "all_votes": votes
    }


def run(input, **kwargs):
    return {"error": "Not implemented yet"}
