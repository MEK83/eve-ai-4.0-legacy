
# specs/executive_function/arbitration_strategy.py

from . import voting, weighting

def arbitrate(module_reports, strategy="voting"):
    """
    Selects the arbitration strategy.
    Accepts module_reports as either:
      - a dict (with a 'reports' field or similar structure)
      - a string (single report, or to be parsed as needed)
      - a list (already normalized)
    """

    # --- Universal input-handling pattern ---
    if isinstance(module_reports, dict):
        # Try to extract the list of reports from a known key
        reports = module_reports.get("reports", [])
        # Optionally, handle other fields as needed for your arbitration logic
    elif isinstance(module_reports, str):
        # If a string, treat as a single report (wrap in a list)
        reports = [module_reports]
    elif isinstance(module_reports, list):
        # Already a list of reports
        reports = module_reports
    else:
        # Fallback for unexpected types
        reports = []

    # --- Arbitration logic ---
    if strategy == "weighting":
        return weighting.weighted_arbitrate(reports)
    else:
        return voting.arbitrate(reports)


def run(input, **kwargs):
    return {"error": "Not implemented yet"}
