
# specs/executive_function/weighting.py

MODULE_WEIGHTS = {
    "nlp": 1.0,
    "speech": 1.0,
    # Add more modules and their weights as needed
}

def weighted_arbitrate(module_reports):
    """
    Applies module-specific weights to confidence scores.
    Accepts module_reports as dict, string, or list.
    Returns the suggestion with the highest weighted score.
    """

    # --- Universal input-handling pattern ---
    if isinstance(module_reports, dict):
        reports = module_reports
    elif isinstance(module_reports, str):
        reports = {"default": {"suggestion": module_reports, "confidence": 1.0}}
    elif isinstance(module_reports, list):
        reports = {f"module_{i}": {"suggestion": r, "confidence": 1.0} for i, r in enumerate(module_reports)}
    else:
        reports = {}

    weighted_votes = {}
    for mod, report in reports.items():
        suggestion = report.get('suggestion')
        confidence = report.get('confidence', 0)
        weight = MODULE_WEIGHTS.get(mod, 1.0)
        if suggestion is not None:
            weighted_votes[suggestion] = weighted_votes.get(suggestion, 0) + confidence * weight

    if not weighted_votes:
        return {"winning_suggestion": None, "reason": "No suggestions found."}

    winning_suggestion = max(weighted_votes, key=weighted_votes.get)
    return {
        "winning_suggestion": winning_suggestion,
        "winning_confidence": weighted_votes[winning_suggestion],
        "all_weighted_votes": weighted_votes
    }


def run(input, **kwargs):
    return {"error": "Not implemented yet"}
