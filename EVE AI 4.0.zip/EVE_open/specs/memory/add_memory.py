
import os
import json
import time

def load_memory(file_path):
    if os.path.exists(file_path):
        with open(file_path, "r", encoding="utf-8") as f:
            return json.load(f)
    return {}

def save_memory(facts, file_path):
    with open(file_path, "w", encoding="utf-8") as f:
        json.dump(facts, f)

def prune_least_used(facts):
    if facts:
        least_used = sorted(facts.items(), key=lambda item: item[1]["access_count"])
        del facts[least_used[0][0]]
    return facts

def remember(facts, key, value, tags=None, max_size=100, file_path=None):
    if len(facts) >= max_size:
        facts = prune_least_used(facts)
    facts[key] = {
        "value": value,
        "last_accessed": time.time(),
        "access_count": 1,
        "tags": tags or []
    }
    if file_path:
        save_memory(facts, file_path)
    return facts


def run(input, **kwargs):
    # Handle string input
    if isinstance(input, str):
        text = input
    # Handle dict input with 'text' key
    elif isinstance(input, dict):
        text = input.get('text', '')
    # Handle list input (optional: join or process each item)
    elif isinstance(input, list):
        # If list of dicts with 'text', join them
        if all(isinstance(i, dict) and 'text' in i for i in input):
            text = ' '.join(i['text'] for i in input)
        else:
            text = str(input)
    else:
        return {"error": f"Unsupported input type: {type(input)}"}

    # Now text is always a string
    try:
        # Replace with your actual logic if needed
        return text.lower()
    except Exception as e:
        return {"error": str(e)}