
import os
import json
import time

def load_memory(file_path):
    if os.path.exists(file_path):
        with open(file_path, "r", encoding="utf-8") as f:
            return json.load(f)
    return {}

def save_memory(facts, file_path):
    with open(file_path, "w", encoding="utf-8") as f:
        json.dump(facts, f)

def levenshtein(s1, s2):
    if len(s1) < len(s2):
        return levenshtein(s2, s1)
    if len(s2) == 0:
        return len(s1)
    previous_row = range(len(s2) + 1)
    for i, c1 in enumerate(s1):
        current_row = [i + 1]
        for j, c2 in enumerate(s2):
            insertions = previous_row[j + 1] + 1
            deletions = current_row[j] + 1
            substitutions = previous_row[j] + (c1 != c2)
            current_row.append(min(insertions, deletions, substitutions))
        previous_row = current_row
    return previous_row[-1]

def recall(facts, query, file_path=None):
    # Try exact, substring, then fuzzy match
    for k in facts:
        if query.lower() == k.lower():
            facts[k]["last_accessed"] = time.time()
            facts[k]["access_count"] += 1
            if file_path:
                save_memory(facts, file_path)
            return facts[k]["value"]
    for k in facts:
        if query.lower() in k.lower():
            facts[k]["last_accessed"] = time.time()
            facts[k]["access_count"] += 1
            if file_path:
                save_memory(facts, file_path)
            return facts[k]["value"]
    for k in facts:
        if levenshtein(query.lower(), k.lower()) <= 2:
            facts[k]["last_accessed"] = time.time()
            facts[k]["access_count"] += 1
            if file_path:
                save_memory(facts, file_path)
            return facts[k]["value"]
    return None


def run(input, **kwargs):
    # Handle string input
    if isinstance(input, str):
        text = input
    # Handle dict input with 'text' key
    elif isinstance(input, dict):
        text = input.get('text', '')
    # Handle list input (optional: join or process each item)
    elif isinstance(input, list):
        # If list of dicts with 'text', join them
        if all(isinstance(i, dict) and 'text' in i for i in input):
            text = ' '.join(i['text'] for i in input)
        else:
            text = str(input)
    else:
        return {"error": f"Unsupported input type: {type(input)}"}

    # Now text is always a string
    try:
        # Replace with your actual logic if needed
        return text.lower()
    except Exception as e:
        return {"error": str(e)}