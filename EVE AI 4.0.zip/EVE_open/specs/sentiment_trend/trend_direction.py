
# specs/sentiment_trend/trend_direction.py

def run(input, **kwargs):
    # Handle string input
    if isinstance(input, str):
        text = input
    # Handle dict input with 'text' key
    elif isinstance(input, dict):
        text = input.get('text', '')
    # Handle list input (optional: join or process each item)
    elif isinstance(input, list):
        # If list of dicts with 'text', join them
        if all(isinstance(i, dict) and 'text' in i for i in input):
            text = ' '.join(i['text'] for i in input)
        else:
            text = str(input)
    else:
        return {"error": f"Unsupported input type: {type(input)}"}

    # Now text is always a string
    try:
        # Replace with your actual logic if needed
        return text.lower()
    except Exception as e:
        return {"error": str(e)}

def run(user_input, shared_context=None, trend_history=None, **kwargs):
    """
    Classifies the overall trend as rising, falling, or stable.
    """
    if trend_history is None or len(trend_history) < 2:
        return {"trend_direction": "stable"}
    if trend_history[-1] > trend_history[0]:
        return {"trend_direction": "rising"}
    elif trend_history[-1] < trend_history[0]:
        return {"trend_direction": "falling"}
    else:
        return {"trend_direction": "stable"}
