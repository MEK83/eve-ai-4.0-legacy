
# Open backend in new PowerShell window
Start-Process powershell -ArgumentList "-NoExit", "-Command", "cd '$PSScriptRoot'; ai-env\Scripts\activate; python api.py"

# Wait a few seconds for backend to start
Start-Sleep -Seconds 5

# Open frontend in new PowerShell window
Start-Process powershell -ArgumentList "-NoExit", "-Command", "cd '$PSScriptRoot\frontend'; npm start"
