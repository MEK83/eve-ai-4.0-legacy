
# core/WorkingMemoryManager.py

import time

class WorkingMemoryManager:
    def __init__(self, shared_context=None, buffer_size=20):
        self.shared_context = shared_context if shared_context is not None else {}
        self.buffer_size = buffer_size
        # Initialize working memory keys if not present
        self.shared_context.setdefault("recent_inputs", [])
        self.shared_context.setdefault("module_outputs", {})
        self.shared_context.setdefault("session_history", [])
        self.shared_context.setdefault("active_goals", [])
        self.shared_context.setdefault("contextual_tags", [])
        self.shared_context.setdefault("user_profile", {})
        self.shared_context.setdefault("triggers", [])

    def add_input(self, user_input):
        entry = {"timestamp": time.time(), "input": user_input}
        self.shared_context["recent_inputs"].append(entry)
        # Keep buffer size
        self.shared_context["recent_inputs"] = self.shared_context["recent_inputs"][-self.buffer_size:]

    def add_module_output(self, module_name, output, confidence=1.0):
        self.shared_context["module_outputs"][module_name] = {
            "output": output,
            "confidence": confidence,
            "timestamp": time.time()
        }

    def add_session_event(self, event):
        self.shared_context["session_history"].append({
            "timestamp": time.time(),
            "event": event
        })
        self.shared_context["session_history"] = self.shared_context["session_history"][-self.buffer_size:]

    def add_goal(self, goal):
        self.shared_context["active_goals"].append(goal)

    def add_tag(self, tag):
        if tag not in self.shared_context["contextual_tags"]:
            self.shared_context["contextual_tags"].append(tag)

    def set_user_profile(self, profile_dict):
        self.shared_context["user_profile"].update(profile_dict)

    def add_trigger(self, trigger):
        self.shared_context["triggers"].append({
            "timestamp": time.time(),
            "trigger": trigger
        })

    def get_memory_snapshot(self):
        return {k: self.shared_context[k] for k in [
            "recent_inputs", "module_outputs", "session_history",
            "active_goals", "contextual_tags", "user_profile", "triggers"
        ]}

    # Add more helper methods as needed for your use cases
