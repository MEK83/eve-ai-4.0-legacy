
import React, { useState, useEffect, useRef } from 'react';

function App() {
  const [modules, setModules] = useState([]);
  const [selectedModule, setSelectedModule] = useState('');
  const [specs, setSpecs] = useState([
    'generate_response',
    'speech_to_text',
    'text_to_speech',
    'manage_history',
    'set_tone',
    'summarize',
    'analyze_sentiment',
    'add_memory',
    'recall_memory',
    'describe_personality',
    'update_self_identity',
    // Add more as your backend grows!
  ]);
  const [selectedSpec, setSelectedSpec] = useState('generate_response');
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState([]);
  const [backend, setBackend] = useState('mistral');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const chatEndRef = useRef(null);
  const BASE_URL = 'http://127.0.0.1:5000';

  // Fetch available modules on load
  useEffect(() => {
    setLoading(true);
    fetch(`${BASE_URL}/modules`)
      .then(res => res.json())
      .then(data => {
        if (data.modules && Array.isArray(data.modules)) {
          setModules(data.modules);
          if (data.modules.length > 0) setSelectedModule(data.modules[0]);
        } else {
          setError(data.error || 'Could not load modules from backend.');
        }
        setLoading(false);
      })
      .catch(() => {
        setError('Could not load modules from backend.');
        setLoading(false);
      });
  }, []);

  // Auto-scroll to latest message
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  // Send message to backend
  const sendMessage = async () => {
    if (!input.trim() || !selectedModule || !selectedSpec) return;
    setMessages([...messages, { sender: 'You', text: input }]);
    setError('');
    setLoading(true);
    try {
      const res = await fetch(`${BASE_URL}/chat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          module: selectedModule,
          message: input,
          action: selectedSpec,
          backend: backend
        }),
      });
      const data = await res.json();
      let botText = '';
      if (res.ok) {
        if (typeof data.response === 'object') {
          botText = data.response.response || data.response.text || data.response.audio || JSON.stringify(data.response);
        } else {
          botText = data.response;
        }
      } else {
        botText = data.error || 'Unknown backend error.';
        setError('Backend returned an error.');
      }
      setMessages(msgs => [...msgs, { sender: selectedModule, text: botText }]);
    } catch (e) {
      setError('Could not reach backend.');
      setMessages(msgs => [...msgs, { sender: 'System', text: 'Could not reach backend.' }]);
      console.error(e);
    }
    setInput('');
    setLoading(false);
  };

  // Handle Enter key for sending
  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !loading) sendMessage();
  };

  return (
    <div style={{
      maxWidth: 700,
      margin: 'auto',
      padding: 24,
      fontFamily: 'Segoe UI, Arial, sans-serif'
    }}>
      <h2 style={{ textAlign: 'center', marginBottom: 24 }}>🧠 Modular AI Chat</h2>
      <div style={{
        display: 'flex',
        gap: 8,
        marginBottom: 16,
        flexWrap: 'wrap'
      }}>
        {/* Module dropdown */}
        <label style={{ flex: 1 }}>
          <span style={{ fontWeight: 500 }}>Module:</span>
          <select
            value={selectedModule}
            onChange={e => setSelectedModule(e.target.value)}
            style={{ width: '100%', padding: 8, borderRadius: 4, marginTop: 4 }}
            disabled={loading || modules.length === 0}
            aria-label="Select module"
          >
            {modules.map(mod => <option key={mod} value={mod}>{mod}</option>)}
          </select>
        </label>
        {/* Spec/mode dropdown */}
        <label style={{ flex: 1 }}>
          <span style={{ fontWeight: 500 }}>Mode/Spec:</span>
          <select
            value={selectedSpec}
            onChange={e => setSelectedSpec(e.target.value)}
            style={{ width: '100%', padding: 8, borderRadius: 4, marginTop: 4 }}
            disabled={loading}
            aria-label="Select mode or spec"
          >
            {specs.map(spec => <option key={spec} value={spec}>{spec.replace(/_/g, ' ')}</option>)}
          </select>
        </label>
        {/* Backend dropdown */}
        <label style={{ flex: 1 }}>
          <span style={{ fontWeight: 500 }}>Backend:</span>
          <select
            value={backend}
            onChange={e => setBackend(e.target.value)}
            style={{ width: '100%', padding: 8, borderRadius: 4, marginTop: 4 }}
            disabled={loading}
            aria-label="Select backend"
          >
            <option value="mistral">Mistral</option>
            <option value="huggingface">HuggingFace</option>
          </select>
        </label>
      </div>
      <div style={{
        border: '1px solid #ccc',
        borderRadius: 8,
        padding: 16,
        minHeight: 240,
        marginBottom: 16,
        background: '#fafafa',
        overflowY: 'auto',
        maxHeight: 350
      }}>
        {messages.map((msg, idx) => (
          <div key={idx} style={{
            marginBottom: 10,
            textAlign: msg.sender === 'You' ? 'right' : 'left'
          }}>
            <span style={{
              fontWeight: 600,
              color: msg.sender === 'You' ? '#0078d4' : '#333'
            }}>
              {msg.sender}:
            </span>
            <span style={{
              marginLeft: 8,
              background: msg.sender === 'You' ? '#e6f4ff' : '#f3f3f3',
              padding: '4px 10px',
              borderRadius: 6,
              display: 'inline-block',
              maxWidth: '80%',
              wordBreak: 'break-word'
            }}>
              {msg.text}
            </span>
          </div>
        ))}
        <div ref={chatEndRef} />
      </div>
      <div style={{ display: 'flex', gap: 8 }}>
        <input
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="Type your message..."
          style={{
            flex: 1,
            padding: 12,
            borderRadius: 8,
            border: '1px solid #ccc',
            fontSize: 16
          }}
          disabled={loading}
          aria-label="Type your message"
        />
        <button
          onClick={sendMessage}
          style={{
            padding: '12px 24px',
            borderRadius: 8,
            background: '#0078d4',
            color: '#fff',
            border: 'none',
            fontWeight: 600,
            cursor: loading ? 'not-allowed' : 'pointer'
          }}
          disabled={loading}
        >
          {loading ? 'Sending...' : 'Send'}
        </button>
      </div>
      {error && (
        <div style={{ color: 'red', marginTop: 16, textAlign: 'center' }}>{error}</div>
      )}
      <div style={{ marginTop: 32, textAlign: 'center', color: '#888', fontSize: 14 }}>
        Modular AI Chat © {new Date().getFullYear()}
      </div>
    </div>
  );
}

export default App;
